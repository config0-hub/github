#!/usr/bin/env python

import os
import json
import boto3

def handler(event, context):

    # Extract payload from the event
    payload = json.loads(event['body'])

    # Get the Step Function ARN from the environment variable
    state_machine_arn = os.environ['STATE_MACHINE_ARN']

    # Create a Step Functions client
    stepfunctions = boto3.client('stepfunctions')

    # Start the Step Function with the payload
    response = stepfunctions.start_execution(
        stateMachineArn=state_machine_arn,
        input=json.dumps(payload)
    )

    # Return a response
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Step Function triggered successfully',
            'executionArn': response['executionArn']
        })
    }
